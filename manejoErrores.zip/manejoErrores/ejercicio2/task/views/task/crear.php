<form action="<?=base_url?>Task/guardar" method="post">
    <label for="task">Ingrese su tarea</label>
    <input type="text" name="task">

    <button type="submit">Crear tarea</button>
</form>