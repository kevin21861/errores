<?php
echo "El resultado es: ". $div->calcular();