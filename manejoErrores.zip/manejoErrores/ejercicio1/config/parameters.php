<?php
define ("base_url", "http://localhost/manejoErrores/manejoErrores/ejercicio1/");
define("controller_default", "defaultController");
define("action_default", "index");